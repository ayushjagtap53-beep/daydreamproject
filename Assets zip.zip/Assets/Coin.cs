using UnityEngine;

public class Coin : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the object that touched the coin has the "Player" tag
        if (other.CompareTag("Player"))
        {
            Destroy(gameObject); // Destroy the coin
        }
    }
}

