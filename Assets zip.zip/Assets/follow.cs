using UnityEngine;

public class CameraFollow2D : MonoBehaviour
{
    public Transform player;   // Player reference
    public float smoothSpeed = 0.125f;
    public Vector3 offset;     // Usually (0, 0, -10) for 2D

    void LateUpdate()
    {
        Vector3 desiredPosition = player.position + offset;
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;
    }
}
